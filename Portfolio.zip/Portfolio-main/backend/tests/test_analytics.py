"""Tests for iteration 2 — analytics endpoints + sendBeacon Blob payload compatibility."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL").rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ----- /api/health regression -----
def test_health_still_ok(session):
    r = session.get(f"{API}/health")
    assert r.status_code == 200
    assert r.json().get("status") == "ok"


# ----- /api/analytics/event -----
class TestAnalyticsEvent:
    def test_post_event_basic(self, session):
        payload = {
            "event": "TEST_page_view",
            "payload": {"path": "/", "width": 1920},
            "source": "https://example.com/",
        }
        r = session.post(f"{API}/analytics/event", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["event"] == "TEST_page_view"
        assert data["payload"] == {"path": "/", "width": 1920}
        assert data["source"] == "https://example.com/"
        assert "id" in data and isinstance(data["id"], str)
        assert "timestamp" in data
        assert "_id" not in data

    def test_post_event_minimal(self, session):
        r = session.post(f"{API}/analytics/event", json={"event": "TEST_scroll_depth"})
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["event"] == "TEST_scroll_depth"
        assert data.get("payload") in (None, {})
        assert data.get("source") in ("", None)
        assert "_id" not in data

    def test_post_event_missing_event_field(self, session):
        r = session.post(f"{API}/analytics/event", json={"payload": {"x": 1}})
        assert r.status_code == 422

    def test_post_event_via_sendbeacon_blob(self):
        """navigator.sendBeacon sends a Blob — content type is application/json
        but no charset and no Content-Type header from session. FastAPI should still parse it.
        Simulate by posting raw bytes."""
        import json as _json
        body = {"event": "TEST_beacon", "payload": {"foo": "bar"}, "source": "beacon"}
        r = requests.post(
            f"{API}/analytics/event",
            data=_json.dumps(body),
            headers={"Content-Type": "application/json"},
        )
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["event"] == "TEST_beacon"
        assert data["payload"] == {"foo": "bar"}

    def test_get_event_list_no_filter(self, session):
        r = session.get(f"{API}/analytics/event")
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 3
        for item in data:
            assert "_id" not in item
            assert "id" in item
            assert "event" in item
            assert "timestamp" in item
        timestamps = [item["timestamp"] for item in data]
        assert timestamps == sorted(timestamps, reverse=True), "Not descending"

    def test_get_event_list_filter(self, session):
        r = session.get(f"{API}/analytics/event", params={"event": "TEST_beacon"})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        for item in data:
            assert item["event"] == "TEST_beacon"

    def test_get_event_list_limit(self, session):
        r = session.get(f"{API}/analytics/event", params={"limit": 2})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) <= 2


# ----- /api/analytics/summary -----
class TestAnalyticsSummary:
    def test_summary_structure(self, session):
        r = session.get(f"{API}/analytics/summary")
        assert r.status_code == 200, r.text
        data = r.json()
        assert "totals" in data
        assert "total_events" in data
        assert isinstance(data["totals"], dict)
        assert isinstance(data["total_events"], int)
        # Totals must equal sum of values
        assert data["total_events"] == sum(data["totals"].values())
        # Our TEST_ events should be present
        assert "TEST_page_view" in data["totals"]
        assert "TEST_beacon" in data["totals"]


# ----- contact-intent regression (iteration 1 endpoints still work) -----
class TestContactIntentRegression:
    def test_post_contact(self, session):
        r = session.post(
            f"{API}/contact-intent",
            json={"kind": "freelance", "subject": "TEST_iter2", "source": "regression"},
        )
        assert r.status_code == 200
        data = r.json()
        assert data["kind"] == "freelance"
        assert "_id" not in data
        assert "id" in data

    def test_get_contact(self, session):
        r = session.get(f"{API}/contact-intent")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        for item in data:
            assert "_id" not in item
