"""Iteration 4 — Admin auth, /api/content, content CRUD, and image upload tests."""
import os
import io
import base64
import pytest
import requests

BASE_URL = os.environ.get(
    "REACT_APP_BACKEND_URL",
    "https://architect-ai-25.preview.emergentagent.com",
).rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@alimoizuddin.site"
ADMIN_PASSWORD = "Editor2026!"

EXPECTED_CONTENT_KEYS = [
    "profile", "socials", "stats", "philosophy", "about", "contactCards",
    "competencies", "agents", "experience", "certifications", "education",
    "projectCategories", "stackMarquee", "projects",
]

# 1x1 PNG (transparent)
_PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
)


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def admin_token(session):
    r = session.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    data = r.json()
    assert "token" in data and isinstance(data["token"], str)
    return data["token"]


@pytest.fixture(scope="module")
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ----- Auth -----
class TestAuth:
    def test_login_success(self, session):
        r = session.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r.status_code == 200, r.text
        data = r.json()
        assert "token" in data
        assert isinstance(data["token"], str)
        # JWT 3-part dot-separated, ~190+ chars
        assert data["token"].count(".") == 2
        assert len(data["token"]) >= 100
        user = data.get("user", {})
        assert user.get("email") == ADMIN_EMAIL
        assert user.get("role") == "admin"
        assert "name" in user

    def test_login_wrong_password(self, session):
        r = session.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": "wrong-password"})
        assert r.status_code == 401, r.text

    def test_login_unknown_email(self, session):
        r = session.post(f"{API}/auth/login", json={"email": "nope@nope.com", "password": "whatever"})
        assert r.status_code == 401

    def test_me_no_auth(self, session):
        r = session.get(f"{API}/auth/me")
        assert r.status_code == 401

    def test_me_invalid_token(self, session):
        r = session.get(f"{API}/auth/me", headers={"Authorization": "Bearer not.a.token"})
        assert r.status_code == 401

    def test_me_with_token(self, session, auth_headers):
        r = session.get(f"{API}/auth/me", headers=auth_headers)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == ADMIN_EMAIL
        assert data["role"] == "admin"
        assert "password_hash" not in data


# ----- /api/content -----
class TestContentPublic:
    def test_content_has_all_keys(self, session):
        r = session.get(f"{API}/content")
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, dict)
        for k in EXPECTED_CONTENT_KEYS:
            assert k in data, f"Missing content key: {k}"
        assert "_id" not in data

    def test_projects_count_28(self, session):
        r = session.get(f"{API}/content")
        data = r.json()
        projects = data.get("projects") or []
        assert isinstance(projects, list)
        assert len(projects) == 28, f"Expected 28 projects, got {len(projects)}"

    def test_content_section_endpoint(self, session):
        r = session.get(f"{API}/content/profile")
        assert r.status_code == 200
        data = r.json()
        assert "profile" in data
        assert isinstance(data["profile"], dict)

    def test_content_section_invalid(self, session):
        r = session.get(f"{API}/content/no-such-section")
        assert r.status_code == 404


# ----- Admin CRUD -----
class TestAdminContent:
    def test_put_profile_requires_auth(self, session):
        r = session.put(f"{API}/admin/content/profile", json={"value": {"tagline": "X"}})
        assert r.status_code == 401

    def test_put_invalid_section_returns_400(self, session, auth_headers):
        r = session.put(
            f"{API}/admin/content/invalid-section",
            json={"value": {"x": 1}},
            headers=auth_headers,
        )
        assert r.status_code == 400, r.text

    def test_put_profile_persists(self, session, auth_headers):
        # capture original
        original = session.get(f"{API}/content").json().get("profile", {})
        new_tagline = "TEST tagline iteration4"
        new_profile = {**original, "tagline": new_tagline}
        r = session.put(
            f"{API}/admin/content/profile",
            json={"value": new_profile},
            headers=auth_headers,
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body.get("ok") is True
        assert body.get("section") == "profile"
        # re-fetch
        r2 = session.get(f"{API}/content")
        assert r2.status_code == 200
        assert r2.json()["profile"]["tagline"] == new_tagline
        # restore
        r3 = session.put(
            f"{API}/admin/content/profile",
            json={"value": original},
            headers=auth_headers,
        )
        assert r3.status_code == 200

    def test_admin_content_requires_auth(self, session):
        r = session.get(f"{API}/admin/content")
        assert r.status_code == 401

    def test_admin_content_with_auth(self, session, auth_headers):
        r = session.get(f"{API}/admin/content", headers=auth_headers)
        assert r.status_code == 200
        data = r.json()
        for k in EXPECTED_CONTENT_KEYS:
            assert k in data


# ----- Image upload -----
class TestUploads:
    def test_upload_requires_auth(self, session):
        # Don't use session-level Content-Type for multipart
        r = requests.post(f"{API}/admin/upload", files={"file": ("a.png", io.BytesIO(_PNG_1X1), "image/png")})
        assert r.status_code == 401

    def test_upload_and_serve_and_delete(self, auth_headers):
        # upload
        r = requests.post(
            f"{API}/admin/upload",
            files={"file": ("test_tiny.png", io.BytesIO(_PNG_1X1), "image/png")},
            headers={"Authorization": auth_headers["Authorization"]},
        )
        assert r.status_code == 200, r.text
        data = r.json()
        assert "id" in data
        assert data["url"] == f"/api/uploads/{data['id']}"
        assert data["filename"] == "test_tiny.png"
        assert data["size"] == len(_PNG_1X1)
        image_id = data["id"]

        # serve
        r2 = requests.get(f"{API}/uploads/{image_id}")
        assert r2.status_code == 200
        assert r2.headers.get("content-type", "").startswith("image/")
        assert r2.content == _PNG_1X1

        # admin list contains it
        r3 = requests.get(f"{API}/admin/uploads", headers={"Authorization": auth_headers["Authorization"]})
        assert r3.status_code == 200
        assert any(u.get("id") == image_id for u in r3.json())

        # delete
        r4 = requests.delete(
            f"{API}/admin/uploads/{image_id}",
            headers={"Authorization": auth_headers["Authorization"]},
        )
        assert r4.status_code == 200
        assert r4.json().get("deleted") == 1

        # gone
        r5 = requests.get(f"{API}/uploads/{image_id}")
        assert r5.status_code == 404

    def test_serve_unknown_id_404(self):
        r = requests.get(f"{API}/uploads/does-not-exist-xyz")
        assert r.status_code == 404
