"""Iteration 5: Contact messages + admin inquiries tests."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://architect-ai-25.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "admin@alimoizuddin.site"
ADMIN_PASSWORD = "Editor2026!"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=20)
    assert r.status_code == 200, f"login failed: {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ---------- POST /api/contact-message (public) ----------
class TestContactMessagePublic:
    def test_post_contact_message_public(self):
        payload = {
            "kind": "freelance",
            "name": "TEST_Sender Iter5",
            "email": "test_iter5@example.com",
            "message": "TEST_iter5 — automated contact message",
            "source": "https://example.com/contact",
        }
        r = requests.post(f"{BASE_URL}/api/contact-message", json=payload, timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["kind"] == "freelance"
        assert data["name"] == payload["name"]
        assert data["email"] == payload["email"]
        assert data["message"] == payload["message"]
        assert data["read"] is False
        assert isinstance(data["id"], str) and len(data["id"]) > 10
        assert "timestamp" in data
        assert "_id" not in data
        # Stash for next tests
        pytest.created_msg_id = data["id"]

    def test_post_contact_message_missing_fields(self):
        # Pydantic should 422 when required fields missing
        r = requests.post(f"{BASE_URL}/api/contact-message", json={"kind": "x"}, timeout=20)
        assert r.status_code == 422


# ---------- GET /api/admin/contact-messages ----------
class TestAdminListMessages:
    def test_list_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/admin/contact-messages", timeout=20)
        assert r.status_code == 401

    def test_list_with_admin_token(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/admin/contact-messages", headers=admin_headers, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        # No _id leakage
        for m in data:
            assert "_id" not in m
            assert "id" in m and "kind" in m and "name" in m and "email" in m and "read" in m
        # Descending by timestamp - the one we just created should be in list
        ids = [m["id"] for m in data]
        assert pytest.created_msg_id in ids
        # First entry is most recent
        first = data[0]
        assert "timestamp" in first


# ---------- PUT /api/admin/contact-messages/{id}/read ----------
class TestMarkRead:
    def test_mark_read_requires_auth(self):
        r = requests.put(f"{BASE_URL}/api/admin/contact-messages/{pytest.created_msg_id}/read", timeout=20)
        assert r.status_code == 401

    def test_mark_read_success(self, admin_headers):
        r = requests.put(
            f"{BASE_URL}/api/admin/contact-messages/{pytest.created_msg_id}/read",
            headers=admin_headers, timeout=20,
        )
        assert r.status_code == 200
        body = r.json()
        assert body.get("updated") == 1

        # Verify persisted via re-listing
        rl = requests.get(f"{BASE_URL}/api/admin/contact-messages", headers=admin_headers, timeout=20)
        assert rl.status_code == 200
        match = next((m for m in rl.json() if m["id"] == pytest.created_msg_id), None)
        assert match is not None
        assert match["read"] is True


# ---------- GET /api/admin/contact-intents ----------
class TestAdminIntents:
    def test_intents_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/admin/contact-intents", timeout=20)
        assert r.status_code == 401

    def test_intents_with_admin(self, admin_headers):
        # Create one first via public endpoint
        seed = requests.post(
            f"{BASE_URL}/api/contact-intent",
            json={"kind": "freelance", "subject": "TEST_iter5 subject", "source": "test"},
            timeout=20,
        )
        assert seed.status_code == 200
        r = requests.get(f"{BASE_URL}/api/admin/contact-intents", headers=admin_headers, timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        for i in data:
            assert "_id" not in i


# ---------- DELETE /api/admin/contact-messages/{id} ----------
class TestDeleteMessage:
    def test_delete_requires_auth(self):
        r = requests.delete(f"{BASE_URL}/api/admin/contact-messages/{pytest.created_msg_id}", timeout=20)
        assert r.status_code == 401

    def test_delete_success(self, admin_headers):
        r = requests.delete(
            f"{BASE_URL}/api/admin/contact-messages/{pytest.created_msg_id}",
            headers=admin_headers, timeout=20,
        )
        assert r.status_code == 200
        assert r.json().get("deleted") == 1
        # Verify gone
        rl = requests.get(f"{BASE_URL}/api/admin/contact-messages", headers=admin_headers, timeout=20)
        ids = [m["id"] for m in rl.json()]
        assert pytest.created_msg_id not in ids


# ---------- Regression: login, content, analytics ----------
class TestRegression:
    def test_login_works(self):
        r = requests.post(f"{BASE_URL}/api/auth/login",
                          json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=20)
        assert r.status_code == 200
        assert "token" in r.json()

    def test_content_get(self):
        r = requests.get(f"{BASE_URL}/api/content", timeout=20)
        assert r.status_code == 200
        data = r.json()
        assert "profile" in data and "contactCards" in data

    def test_admin_content_put(self, admin_headers):
        # Get current
        cur = requests.get(f"{BASE_URL}/api/content", timeout=20).json()
        original_profile = cur["profile"]
        # PUT same value back (no-op edit)
        r = requests.put(
            f"{BASE_URL}/api/admin/content/profile",
            headers=admin_headers,
            json={"value": original_profile},
            timeout=20,
        )
        assert r.status_code == 200
        assert r.json().get("ok") is True

    def test_analytics_event(self):
        r = requests.post(
            f"{BASE_URL}/api/analytics/event",
            json={"event": "TEST_iter5_event", "payload": {"a": 1}, "source": "test"},
            timeout=20,
        )
        assert r.status_code == 200
        assert r.json()["event"] == "TEST_iter5_event"
