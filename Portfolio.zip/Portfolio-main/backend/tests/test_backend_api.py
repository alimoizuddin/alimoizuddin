"""Backend API tests for Ali Moizuddin personal brand site."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://architect-ai-25.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"


@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


# ----- Health/status endpoints -----
class TestHealth:
    def test_root_api(self, session):
        r = session.get(f"{API}/")
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("status") == "ok"
        assert "message" in data

    def test_health(self, session):
        r = session.get(f"{API}/health")
        assert r.status_code == 200, r.text
        data = r.json()
        assert data.get("status") == "ok"
        assert data.get("service") == "personal-brand"
        assert "time" in data


# ----- Legacy /status endpoint -----
class TestStatusLegacy:
    def test_create_status(self, session):
        r = session.post(f"{API}/status", json={"client_name": "TEST_client"})
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["client_name"] == "TEST_client"
        assert "id" in data and isinstance(data["id"], str)
        assert "timestamp" in data
        assert "_id" not in data

    def test_get_status_list(self, session):
        r = session.get(f"{API}/status")
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        for item in data:
            assert "_id" not in item


# ----- Contact intent endpoints -----
class TestContactIntent:
    def test_create_freelance_intent(self, session):
        payload = {
            "kind": "freelance",
            "subject": "Freelance Inquiry — TEST",
            "source": "https://example.com/test",
        }
        r = session.post(f"{API}/contact-intent", json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["kind"] == "freelance"
        assert data["subject"] == "Freelance Inquiry — TEST"
        assert data["source"] == "https://example.com/test"
        assert "id" in data and isinstance(data["id"], str)
        assert "timestamp" in data
        assert "_id" not in data

    def test_create_hiring_intent(self, session):
        r = session.post(
            f"{API}/contact-intent",
            json={"kind": "hiring", "subject": "Hiring TEST", "source": ""},
        )
        assert r.status_code == 200
        assert r.json()["kind"] == "hiring"

    def test_create_collab_intent(self, session):
        r = session.post(
            f"{API}/contact-intent",
            json={"kind": "collab", "subject": "Collab TEST"},
        )
        assert r.status_code == 200
        data = r.json()
        assert data["kind"] == "collab"
        # source is optional and defaults to ""
        assert data.get("source", "") == ""

    def test_list_contact_intents_desc(self, session):
        r = session.get(f"{API}/contact-intent")
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 3  # we just created 3
        for item in data:
            assert "_id" not in item
            assert "id" in item
            assert "kind" in item
            assert "subject" in item
            assert "timestamp" in item
        # verify descending order by timestamp
        timestamps = [item["timestamp"] for item in data]
        assert timestamps == sorted(timestamps, reverse=True), "List not in descending order"

    def test_invalid_payload_missing_fields(self, session):
        r = session.post(f"{API}/contact-intent", json={"kind": "freelance"})
        assert r.status_code == 422  # pydantic validation error
