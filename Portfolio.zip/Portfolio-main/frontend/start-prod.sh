#!/bin/bash
# Self-healing prod-build launcher for the frontend.
# - If node_modules is missing (rare full-container reset), reinstall deps.
# - If build/ is missing (artifact got cleared), rebuild the production bundle.
# - Then exec `serve` to take over the supervised process.
set -e
cd /app/frontend

if [ ! -d node_modules ] || [ ! -x node_modules/.bin/serve ]; then
  echo "[start-prod] node_modules missing — running yarn install..."
  yarn install --frozen-lockfile
fi

if [ ! -f build/index.html ]; then
  echo "[start-prod] build/ missing — running yarn build..."
  yarn build
fi

echo "[start-prod] serving build/ on :3000"
exec node_modules/.bin/serve -s build -l 3000 --no-clipboard
