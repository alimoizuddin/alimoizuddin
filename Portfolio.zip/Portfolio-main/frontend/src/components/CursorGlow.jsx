import React, { useEffect, useState } from "react";

// Subtle cursor-following radial glow. Desktop pointer devices only —
// touch devices skip mounting entirely so there's no mousemove listener overhead.
export default function CursorGlow() {
  const [enabled, setEnabled] = useState(false);
  const [pos, setPos] = useState({ x: -1000, y: -1000 });
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const supportsHover = window.matchMedia?.("(hover: hover) and (pointer: fine)").matches;
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (!supportsHover || reducedMotion) return; // no-op on touch / low-power
    setEnabled(true);

    let raf = 0;
    let nextX = -1000;
    let nextY = -1000;
    const onMove = (e) => {
      nextX = e.clientX;
      nextY = e.clientY;
      if (raf) return;
      raf = requestAnimationFrame(() => {
        setPos({ x: nextX, y: nextY });
        setVisible(true);
        raf = 0;
      });
    };
    const onLeave = () => setVisible(false);
    window.addEventListener("mousemove", onMove, { passive: true });
    window.addEventListener("mouseleave", onLeave);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseleave", onLeave);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
  if (!enabled) return null;

  return (
    <div
      className="cursor-glow"
      style={{ left: pos.x, top: pos.y, opacity: visible ? 1 : 0 }}
      aria-hidden="true"
      data-testid="cursor-glow"
    />
  );
}
